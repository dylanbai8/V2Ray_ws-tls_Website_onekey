https://github.com/v2ray/v2ray-core/releases

下载 v2ray-windows-64.zip 或者 v2ray-windows-32.zip 解压到到 V2rayPro\v2ray 目录

wv2ray-service.exe 为添加自启动服务的依赖文件

目录结构如下：

V2rayPro--便捷启动.bat
		--使用说明.txt
        --v2ray--wv2ray-service.exe
			   --wv2ray.exe
			   --v2ray.exe
			   --其它