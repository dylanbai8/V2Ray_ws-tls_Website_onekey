使用说明：

1.V2ray内核更新
下载 v2ray-windows-64.zip（或者 v2ray-windows-32.zip）解压到到 V2rayPro\v2ray 目录
更新地址：https://github.com/v2ray/v2ray-core/releases

2.自启动服务
V2ray自启动服务（wv2ray-service.exe）基于nssm.exe（64位）实现开机自启动和进程守护
下载最新版 解压 win64\nssm.exe（或 win32\nssm.exe）重命名为 wv2ray-service.exe 后 覆盖到 V2rayPro\v2ray 目录
更新地址：http://www.nssm.cc/builds

目录结构如下：

V2rayPro--便捷启动.bat
		--使用说明.txt
        --v2ray--wv2ray-service.exe
			   --wv2ray.exe
			   --v2ray.exe
			   --v2ctl.exe
			   --其它